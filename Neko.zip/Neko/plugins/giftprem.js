let handler = async (m, {
    conn,
    args,
    text,
    usedPrefix,
    command
}) => {
if (!text) throw 'nomor atau tag nya mana beb?'
let t1 = text.split(' ')

    try {
    let who
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : t1[0] + '@s.whatsapp.net'
else who = m.sender

        let data = global.db.data.users[who]
        if (!args[0]) return m.reply('Jumlah hari?')
        if (data.registered === false && data.registered === 'undefined') return conn.reply(m.chat, `Yah😢 @${who.split('@')[0]} belum terdaftar di database jadi dapet deh`, null)

        let jumlah = 86400000 * t1[1]
        let now = new Date() * 1
        let cap = `Selamat kepada @${who.split('@')[0]} telah mendapatkan *Premium*.\n- ${t1[1]} Hari`

        await conn.reply(m.chat, cap, null, {
            contextInfo: {
                mentionedJid: [who]
            }
        })
        if (now < data.premiumTime) data.premiumTime += jumlah
        else data.premiumTime = now + jumlah
        data.premium = true

    } catch (e) {
        throw eror
    }
}
handler.help = handler.command = ['giftprem']
handler.tags = ['group']
handler.owner = handler.group = true

export default handler