import fetch from 'node-fetch'
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)
let edtr = `@${m.sender.split`@`[0]}`

let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp;Syaa MD\nNICKNAME:👑 Partner Owner Syaa MD\nORG:Syaa MD\nTITLE:soft\nitem1.TEL;waid=6287841480936:+62 878-4148-0936\nitem1.X-ABLabel:📞 Nomor Partner Owner\nitem2.URL:https://github.com/Fhiz-MD/NekoMultiDevice\nitem2.X-ABLabel:💬 More\nitem3.EMAIL;type=INTERNET:thehoki777@gmail.com\nitem3.X-ABLabel:💌 Mail Owner Fhiz MD\nitem4.ADR:;;🇯🇵 japan;;;;\nitem4.X-ABADR:💬 More\nitem4.X-ABLabel:📍 Lokasi Saya\nBDAY;value=date:🐦 12-04-2007\nEND:VCARD`
const tag_own = await conn.sendMessage(m.chat, { contacts: { displayName: wm, contacts: [{ vcard }] }}, { quoted: global.fkontak })
let caption = `👋 Hai *${edtr}*, Nih Owner *${conn.user.name}* kak`
    await conn.reply(m.chat, caption, tag_own, { mentions: conn.parseMention(caption) })

}
handler.help = ['partner', 'creator']
handler.tags = ['info']

handler.command = /^(partner|partnerfhi|syaa)$/i

export default handler