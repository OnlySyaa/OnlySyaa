import fs from 'fs'
let handler = m => m
handler.all = async function (m, { isBlocked }) {
  if (isBlocked) return
  if (
    (m.mtype === 'groupInviteMessage' ||
      m.text.startsWith('Undangan untuk bergabung') ||
      m.text.startsWith('Invitation to join') ||
      m.text.startsWith('Buka tautan ini')) &&
    !m.isBaileys &&
    !m.isGroup
  ) {
    let teks = `Mau nambahin bot ke grup kak gak gratis yaa..

*HARGA:*
➠ *15 hari • Rp 5.000*

➠ *30 hari • Rp 10.000*

➠ *60 hari • Rp 20.000*

➠ *90 hari • Rp 30.000*

➠ *Permanen hari • Rp 40.000*

*Minat? Hubungi*
https://wa.me/6283820995534 [Fhiz]`

    this.reply(m.chat, teks, m)
  }
}

export default handler