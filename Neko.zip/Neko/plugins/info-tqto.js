// Jgn Di Hapus
let handler = async (m) => {

let anu =`
⟥⟞⟚━┈┈ ❨  Info Tqto ❩ ┈┈━⟚⟝⟤ 

*Rᴇᴄᴏᴅᴇ Bʏ* : ʀᴀғᴀᴇʟ
*Wᴀ Owɴᴇʀ* : wa.me//6283857564133
*Sᴄ Oʀɪ* : wa.me//628387564133
*Mʏ Pʀᴏᴊᴇᴄᴛ* : 22 𝐴𝑔𝑢𝑠𝑡𝑢𝑠 2023

⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕

${botdate}
`
await m.reply(anu)
}
handler.help = ['tqto', 'credit']
handler.tags = ['info']
handler.command = /^(tqto|credit)$/i

export default handler

// Yang Hapus Anak Kntolll