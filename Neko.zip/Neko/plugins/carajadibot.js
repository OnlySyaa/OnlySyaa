let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  const caption = `
*❏––––––『 JADIBOT 』––––––❏*

👑Bang Fhiz Melayani👑
-----------------------------------------------------------------
JASA JADIBOT : 15K
JUAL PANEL BOT : 1gb-unli
JUAL ADMIN PANEL : 10k
JASA UNBAN : 3K
MURID UNBAN : 5K
Payment ? Dana/Pulsa

Own Contact : https://wa.me/6283820995534


        ☣ *NEKO AI* ☣

`.trim()
  conn.sendFile(m.chat, 'https://telegra.ph/file/6890ee54916c4de72bf0e.jpg', null, caption, m)
}
handler.help = ['carajadibot']
handler.tags = ['carajadibot']
handler.command = /^(carajadibot)$/i;

handler.register = false
export default handler