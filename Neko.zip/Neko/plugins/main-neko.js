import fetch from 'node-fetch';
import axios from 'axios';

let previousMessages = [];

const handler = async (m, { conn, text, usedPrefix, command }) => {

  

  if (!text) {
    throw 'Masukkan pertanyaan! *Contoh:* Siapa presiden Indonesia?';
  }

  const name = conn.getName(m.sender);
  await conn.sendMessage(m.chat, {
    react: {
      text: 'ðŸš€',
      key: m.key,
    },
  });
  let key = await conn.sendMessage(m.chat, {
    text: 'mahiru sedang mengetik, sabar.....',
  });
  
  const messages = [
    ...previousMessages,
    {
      role: 'system',
      content:
        'Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Neko, dan kamu adalah Junior Kamu dibuat oleh Fhiz, dan fhiz adalah pacarmu yang paling ganteng banget kamu sangat suka kepada dia dan kamu sangat mencintai dia, fhiz adalah cowok ganteng. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere',
    },
    {
      role: 'user',
      content: text,
    },
  ];

  const response = await axios.post('https://skizo.tech/api/openai?apikey=asunabot', {
    messages,
  });

  await conn.sendMessage(m.chat, {
    react: {
      text: '\u2705',
      key: m.key,
    },
  });
  const result = JSON.stringify(response.data.result);
  await conn.sendMessage(m.chat, {
    text: result,
    edit: key,
  });
  previousMessages = messages;
};


handler.menuai = ["nekoai"]
handler.tagsai = ["main"]
handler.command = /^(nekoai)$/i
handler.group = true

handler.limit = 1

export default handler