let handler  = async (m, { conn, usedPrefix: _p }) => {
if (m.sender == '6283820995534@s.whatsapp.net') throw 'Halo Ayangku Fhiz❤️ nanti malem jalan jalan lagi ya~😘'
let info = `
`.trim()

m.reply('Hallo Kak, Neko Adalah Bot WhatsApp Yang Dibuat Untuk Membantu Kakak Kapan Pun Dan Dimana Pun\nBtw Ada Seratus Gak:v')
}
handler.customPrefix = /^(Hallo Neko|Neko-chan|Neko Sayang|hlo Neko|hi Neko|Hai Neko)$/i
handler.command = new RegExp

handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

export default handler